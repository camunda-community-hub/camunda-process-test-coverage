# bpmn-js seed

A simple project to try out [bpmn-js](https://github.com/bpmn-io/bpmn-js), build extensions in or copy from to integrate BPMN 2.0 diagrams into your applications.

Based on the [simple-bower](https://github.com/bpmn-io/bpmn-js-examples/tree/master/simple-bower) and [overlays](https://github.com/bpmn-io/bpmn-js-examples/tree/master/overlays) examples.


## Get it!

* [download](https://github.com/bpmn-io/bpmn-js-seed/archive/master.zip) or
* Clone to your machine via `git clone https://github.com/bpmn-io/bpmn-js-seed.git`


## License

MIT